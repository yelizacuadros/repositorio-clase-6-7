document.addEventListener("DOMContentLoaded", () => {
    
    // ==========================================
    // 1. COMPONENTE INTERACTIVO: CAMBIO DE TEMA
    // ==========================================
    const themeToggleBtn = document.getElementById("theme-toggle");
    const currentTheme = localStorage.getItem("theme") || "light";

    // Aplicar el tema guardado al cargar
    document.documentElement.setAttribute("data-theme", currentTheme);

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener("click", () => {
            let theme = document.documentElement.getAttribute("data-theme");
            let newTheme = theme === "dark" ? "light" : "dark";
            
            document.documentElement.setAttribute("data-theme", newTheme);
            localStorage.setItem("theme", newTheme);
        });
    }

    // ==========================================
    // 2. COMPONENTE INTERACTIVO: FILTRO GALERÍA
    // ==========================================
    const filterButtons = document.querySelectorAll(".filter-btn");
    const galleryItems = document.querySelectorAll(".gallery-item");

    filterButtons.forEach(button => {
        button.addEventListener("click", () => {
            // Remover estado activo de botones previos
            filterButtons.forEach(btn => btn.classList.remove("active"));
            button.classList.add("active");

            const filterValue = button.getAttribute("data-filter");

            // Animación y visualización filtrada
            galleryItems.forEach(item => {
                if (filterValue === "all" || item.getAttribute("data-category") === filterValue) {
                    item.style.display = "flex";
                    setTimeout(() => item.style.opacity = "1", 50);
                } else {
                    item.style.opacity = "0";
                    setTimeout(() => item.style.display = "none", 200);
                }
            });
        });
    });

    // ==========================================
    // 3. VALIDACIÓN DE FORMULARIO EN EL CLIENTE
    // ==========================================
    const contactForm = document.getElementById("art-contact-form");

    if (contactForm) {
        contactForm.addEventListener("submit", (e) => {
            e.preventDefault(); // Detener envío por defecto

            let isFormValid = true;

            // Elementos de Entrada
            const fullname = document.getElementById("fullname");
            const email = document.getElementById("email");
            const role = document.getElementById("role");
            const message = document.getElementById("message");
            const successAlert = document.getElementById("success-alert");

            // Expresión regular para validar formato de correo electrónico
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            // Validación de Nombre
            if (fullname.value.trim().length < 4) {
                fullname.parentElement.classList.add("invalid");
                isFormValid = false;
            } else {
                fullname.parentElement.classList.remove("invalid");
            }

            // Validación de Email
            if (!emailRegex.test(email.value.trim())) {
                email.parentElement.classList.add("invalid");
                isFormValid = false;
            } else {
                email.parentElement.classList.remove("invalid");
            }

            // Validación de Rol
            if (role.value === "") {
                role.parentElement.classList.add("invalid");
                isFormValid = false;
            } else {
                role.parentElement.classList.remove("invalid");
            }

            // Validación de Mensaje
            if (message.value.trim().length < 10) {
                message.parentElement.classList.add("invalid");
                isFormValid = false;
            } else {
                message.parentElement.classList.remove("invalid");
            }

            // Si pasa todo el filtro del cliente, emula el envío exitoso
            if (isFormValid) {
                successAlert.style.display = "block";
                contactForm.reset(); // Limpia los campos
                
                // Ocultar alerta después de unos segundos
                setTimeout(() => {
                    successAlert.style.display = "none";
                }, 4000);
            }
        });

        // Limpiar errores mientras el usuario escribe de manera dinámica
        const inputs = contactForm.querySelectorAll("input, select, textarea");
        inputs.forEach(input => {
            input.addEventListener("input", () => {
                if (input.parentElement.classList.contains("invalid")) {
                    input.parentElement.classList.remove("invalid");
                }
            });
        });
    }
});